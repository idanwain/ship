Instruction Exercise 1 Advanced Topic C++

1. Use make to compile the program, program name is ex1.
2. Run the program and insert as an argument the main folder which contains travel directories.
	Entering the following commands : 
		ex1 example1
		ex1 example2
3. example1 directory includes -
	a. Travel1 � contains valid ship route and port files
	b. Travel2 � contains invalid ship route and invalid ship map(are empty)
	c. Travel3 � same as Travel1 with additional of several containers
4. example2 directory includes �
	a. Travel1 � contains valid ship route and port files.
	b. Travel2 � contains valid ship route and port files.
5. We have 3 algorithms � 
	a. Lifo Algorithm � algorithm that sorts the containers puts at available top floor containers in the order of the following route ports.
	b. Unsorted Lifo Algorithm � almost same variant as lifo, but small changes such it doesn�t sort, it doesn�t check if given container id exists in ship already.
	c. Erroneous Algorithm � this algorithm reject all instructions.
6. Output � created by the program which divides into sub folders of travel numbers given in the Travels folder, each Travel[i]Out folder will include all kind of algorithms crane instructions based on their names and based on the ship route.
	Hierarchy : 
		i. Output
			1. Travel[i]Out
				a. <Algorithm>-<Port Name>_<Port File Number>
			2. Travel[j]Out
				a. <Algorithm>-<Port Name>_<Port File Number>
7. The simulation.results and simulaltion.errors files are created in the main Travel directory as required,i.e it sits in example1, and example2 folders.
8. We have added our expected output based on the simulation run we did in nova on the same files, named example1Output.
9. Notes : we made some assumptions on the input�s it wasn�t written in the exercise 1 guideline, such as no negative numbers given in the ship plans and no negative weight etc�



